sapui5-display_smartform_pdf
============================

Display Smartform (PDF) in SAPUI5.

Please see more details in blog http://scn.sap.com/community/developer-center/front-end/blog/2014/02/03/display-smartform-pdf-in-sapui5
